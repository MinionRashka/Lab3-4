public class Inedible extends Thing{
    public Inedible(String name, Human owner) { super(name, owner); }
    public Inedible(String name) { super(name); }
}
