public class ThingException extends Exception{
    public ThingException(String message){
        super(message);
    }
}
