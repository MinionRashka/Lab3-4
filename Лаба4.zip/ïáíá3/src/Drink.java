public class Drink extends Thing{
    public Drink(String name) { super(name); }
    public Drink(String name, Human owner) { super(name, owner); }
    public void SetOwner(Human owner) {System.out.print("you can't cook drink");}
}
