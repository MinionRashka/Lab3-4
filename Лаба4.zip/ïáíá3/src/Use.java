


public interface Use {
    boolean use (Human human, Thing thing) throws ThingException;

    //void feed(Food food, Human human);
}
