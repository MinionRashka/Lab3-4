import Useless.Car;
import Useless.Manufacturer;

import java.util.ArrayList;

public class Main {


    public static void main(String []Args) throws InterruptedException, ThingException {
        Human kid = new Cook("Малыш", Gender.MALE, 0, 0);
        Human Karlson = new Human("Карлсон", Gender.MALE, 200);
        Human Julius = new Human ("Юлиус", Gender.MALE, 0);
        Human frekenBok = new Human("Фрекен Бок", Gender.FEMALE, 0);
        Human everyone = new Human("Все", Gender.NEITHER, 0);
        ArrayList<Thing> list = new ArrayList<Thing>();
        Drink water = new Drink ("Вода", Karlson);
        list.add(water);
        Food cheese = new Food("cheese", kid, 3, 8);
        Food bread = new Food("bread", kid, 3, 2);
        list.add(cheese);
        list.add(bread);
        Inedible room = new Inedible("Комната", kid);
        list.add(room);

        ReciepList Sandwich = new ReciepList("sandwich", 20);
        Sandwich.putIngridient("cheese");
        Sandwich.putIngridient("bread");

        Interaction interaction1 = new Interaction("мог подоткнуть одеяло", kid, Karlson,false);
        System.out.println(interaction1);

        for (int i=0; i<list.size();i++) {
            ((Cook) kid).use(Karlson, list.get(i));
        }

        Interaction disturb = new Interaction("помешал", everyone, kid,false);
        System.out.println(disturb);

        Interaction speak = new Interaction("разговаривал", frekenBok, Julius, true);
        System.out.println(speak);

        Interaction sorry = new Interaction("простил", frekenBok, Julius, true);
        System.out.println(sorry);

        Interaction come_back = new Interaction("вернулся", kid, room, true);
        System.out.println(come_back);

        Interaction behappy = new Interaction("радоваться", kid, Karlson, true);
        System.out.println(behappy);

        while (cheese.getAmount()>0 && bread.getAmount()>0) {
            Food sandwich = Sandwich.create(cheese.use()+bread.use());
            ((Human) Karlson).eat(Karlson, sandwich, (Cook) kid);
        }


        /*for (int i=0;i<4;i++) System.out.println();
        Manufacturer Mercedes = new Manufacturer("Մերսեդես", "German");
        Car e_klasse = new Car(520, 0,250, 4.5, Mercedes);
        ((Car) e_klasse).turnOn(e_klasse);
        ((Car) e_klasse).use(e_klasse);
        ((Car) e_klasse).accelerate(e_klasse, 120);*/
    }

}
