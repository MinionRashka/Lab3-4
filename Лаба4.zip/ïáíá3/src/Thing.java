import java.util.Objects;

abstract class Thing {
    private String name;
    private int amount;
    private Human owner;

    public Thing (String name, int amount) {
        this.name = name;
        this.amount=amount;
    }
    public Thing (String name, Human owner, int amount){
        this.name = name;
        this.owner = owner;
        this.amount = amount;
    }

    public Thing (String name, Human owner){
        this.name = name;
        this.owner = owner;
    }
    public Thing(String name) {this.name = name;}

    public String getName() {return name;}
    public String use(){
        if (amount>0) {
            amount -= 1;
            return name;
        }
        else return null;
    }

    public String getOwnerName() {return owner.getName();}

    public boolean equals(Object otherObject)  {
        if (this == otherObject) return true;
        if (otherObject == null) return false;
        if (getClass() != otherObject.getClass()) return false;
        Human other = (Human) otherObject;
        return this.getName().equals(other.getName()) && this.getName().equals(other.getName());
    }

    public int hashCode()
    {
        return Objects.hash(name, owner);
    }

    public String toString()
    {
        return getClass().getName() + "[name=" + this.getName() + ",owner=" + this.getOwnerName() + "]";
    }

    public int getAmount() {
        return amount;
    }

    public Human getOwner() {
        return owner;
    }
}
