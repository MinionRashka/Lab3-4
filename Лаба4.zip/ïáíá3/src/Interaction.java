import java.util.Arrays;
import java.util.Objects;

public class Interaction {
    private String action;
    private Human subject;
    private Human target;
    private boolean state;
    private Thing object;

    public Interaction(String action, Human subject, Human target, boolean state) {
        this.subject = subject;
        this.target = target;
        this.action = action;
        this.state = state;

        System.out.print(subject.getName() + " ");
        if (state == false) System.out.print("не ");
        System.out.print(action);
        if (subject.getGender() == Gender.FEMALE) System.out.print("а");
        System.out.println(" " + target.getName());
    }

    public Interaction(String action, Human subject, Thing object, boolean state){
        this.subject = subject;
        this.object = object;
        this.action = action;
        this.state = state;

        System.out.print(subject.getName() + " ");
        if (state == false) System.out.print("не ");
        System.out.print(action);
        if(subject.getName() == object.getOwnerName()) System.out.println(" своё " + object.getName());
        else System.out.println(" " + object.getName() + " " + object.getOwnerName());
    }

    public String getName() {return action;}
    public void setName() {this.action = action;}
    public Human getTarget() {return target;}
    public void setTarget() {this.target = target;}
    public Human getSubject() {return subject;}
    public void setSubject() {this.subject = subject;}
    public Thing getObject() {return object;}
    public void setObject() {this.object = object;}
    public String getObjectOwnerName() {return object.getOwnerName();}
    public boolean getState() {return state;}
    public void setState() {this.state = state;}

    public boolean equals(Object otherObject)  {
        if (this == otherObject) return true;
        if (otherObject == null) return false;
        if (getClass() != otherObject.getClass()) return false;
        Interaction other = (Interaction) otherObject;
        return this.getName().equals(other.getName()) && this.getObject().equals(other.getObject()) && this.getTarget().equals(other.getTarget()) && this.getSubject().equals(other.getSubject());
    }

    public int hashCode(){ return Objects.hash(action, subject, target);}

    public String toString()
    {
            try{
                return getClass().getName() + "[name=" + this.getName() + ",state=" + this.getState() + ",target=" + this.getTarget().toString() + ",subject=" + this.getSubject().toString() + "]";
            }catch (NullPointerException e){
                return getClass().getName() + "[name=" + this.getName() + ",state=" + this.getState() + ",subject=" + this.getSubject().toString()+ ",object=" + this.getObject().toString() + "]";
            }
    }
}