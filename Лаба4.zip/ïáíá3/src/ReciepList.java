import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ReciepList {
    //HashMap<String, String> map = new HashMap<String, String>();
    String name;
    String recipe="";
    int sustanance;


    public ReciepList(String name, int sustanance){
        this.name = name;
        this.sustanance = sustanance;
    }
    public void putIngridient(String ingridientName){
        recipe+=ingridientName;
    }

    public Food create(String ingridients){
        if (ingridients.equals(recipe)) {
            Food foodClass = new Food(name, sustanance, 1);
            System.out.println(name + " был приготовлен");
            return foodClass;
        }
        else {
            System.out.println(name + " не был приготовлен");
            return null;
        }
    }

    public String getRecipe(){
        //this.map.put("sandwich", recipe);
        return recipe;
    }

    /*public ArrayList<String> getList(String recipename) throws NoSuchFieldException, IllegalAccessException{
        Field field = this.getClass().getField(recipename) ;
        field.setAccessible(true);
        return (ArrayList<String>) field.get(this);
    }*/
}
