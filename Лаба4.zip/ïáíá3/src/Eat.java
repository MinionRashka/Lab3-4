public interface Eat {
    boolean eat (Human human, Food food, Cook cook);
}
