public enum Condition {
    HAPPY,
    CONCENTRATED,
    SATISFIED,
    OFFENDED,
    CALM
}
