import java.util.Objects;
import java.util.Scanner;

public class Human implements Eat{

    private String name;
    private Condition condition;
    private Gender gender;
    private int HowStarve;
    Scanner scanner = new Scanner(System.in);
    public Human(String name , Gender gender, int HowStarve){
        this.name = name;
        this.gender = gender;
        try {
            if (HowStarve>=0 && HowStarve <=100) this.HowStarve = HowStarve;
            else throw new ParameterException("Введите нормальное значение параметра HowStarve");
        }catch(Exception e){
            while(HowStarve<0 || HowStarve>100) {
                System.out.println("Введите нормальное значение параметра HowStarve, принадлежащее от 0 включительно до 100 включительно :");
                HowStarve = scanner.nextInt();
                this.HowStarve = HowStarve;
            }
        }
        condition = condition.CALM;
    }

    @Override
    public boolean eat(Human human, Food food, Cook cook) {
        try {
            if (this.HowStarve+food.getSustanance() * cook.getSkills()<=100)
            {
                this.HowStarve += food.getSustanance() * cook.getSkills();
                double mark = Math.random() * food.getSustanance() * cook.getSkills() * 0.01;
                try {
                    if (cook.getSkills() + mark > 1)
                        throw new ParameterException("Нельзя научиться чему-то на больше чем 100%");
                    else cook.setMark(mark);
                } catch (Exception e) {
                    System.out.println("Нельзя научиться чему-то на больше чем 100%");
                    cook.setMark(1 - cook.getSkills());
                }
                System.out.println(human.getName() + " съел " + food.getName() + ". Текущий голод: " + this.HowStarve);
                System.out.println("Оценка: " + String.format("%.1f", mark * 100) + "%");
                this.HowStarve-=5;
            } else throw new EatException ("Вы не голодны более");
        }catch(Exception e){
            System.out.println("Вы не можете съесть больше");
            this.HowStarve=95;
        }
        return true;
    }

    public String getName(){return name;}
    public Condition getCondition(){return condition;}
    public Gender getGender(){return gender;}

    public boolean equals(Object otherObject)  {
        if (this == otherObject) return true;
        if (otherObject == null) return false;
        if (getClass() != otherObject.getClass()) return false;
        Human other = (Human) otherObject;
        return this.getName().equals(other.getName()) && this.getCondition().equals(other.getCondition()) && this.getGender().equals(other.getGender());
    }

    public int hashCode()
    {
        return Objects.hash(name, condition, gender);
    }

    public String toString()
    {
        return getClass().getName() + "[name=" + this.getName() + ",condition=" + this.getCondition().toString() + ",gender=" + this.getGender().toString() + "]";
    }
}
