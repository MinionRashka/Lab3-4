public class ParameterException extends Exception {
    public ParameterException(String message){
        super(message);
    }
}
