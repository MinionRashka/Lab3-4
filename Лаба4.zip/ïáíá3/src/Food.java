public class Food extends Thing {
    private int sustanance;
    public Food(String name, int sustanance, int amount){
        super(name, amount);
        this.sustanance = sustanance;
    }
    public Food(String name, Human owner, int sustanance, int amount) {
        super(name, owner, amount);
        this.sustanance = sustanance;
    }

    public int getSustanance() {
        return sustanance;
    }
}
