package Useless;

public interface Ignition {
    void turnOn(Car car);
    void turnOff(Car car);

    void use(Car car);

    public enum State{
        ON,
        OFF
    }

    void accelerate(Car car, int speed) throws InterruptedException;
}