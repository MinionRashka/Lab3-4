package Useless;

abstract class Engine implements Ignition {
    private int torque;

    public Engine(int torque) {
        this.torque=torque;
    }
    public int getTorque(){return torque;}
}
