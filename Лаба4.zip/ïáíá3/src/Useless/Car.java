package Useless;

import java.util.concurrent.TimeUnit;

public class Car extends Engine {
    private double speed;
    private double Max_speed;
    private double acceleration;
    Manufacturer creator;
    State state = State.OFF;

    public Car(int torque, double speed, double Max_speed, double acceleration, Manufacturer creator) {
        super(torque);
        this.acceleration = acceleration;
        this.speed = speed;
        this.creator = creator;
        this.Max_speed = Max_speed;

        System.out.println ("Создетель: " + creator.getName() + "; Страна производителя: " + creator.getCountry() + "; Скорость машины: " + getSpeed() + "; Ускорение машины:" + getAcceleration());
    }

    public double getSpeed(){return speed;}
    public double getAcceleration(){return acceleration;}

    @Override
    public void turnOn(Car car) {
          state = State.ON;
          System.out.println("Машины заведена");
    }

    @Override
    public void turnOff(Car car) {
        state = State.OFF;
        System.out.println("Машина выключена");
    }

    @Override
    public void use(Car car) {
        System.out.println("Машина едет со скоростью " + getSpeed());
    }

    @Override
    public void accelerate(Car car, int speed) throws InterruptedException {
        while (speed>this.speed && Max_speed>this.speed) {
            this.speed+=100/acceleration;
            System.out.println(String.format("%.1f", this.speed));
            TimeUnit.SECONDS.sleep(2);
        }
    }


    @Override
    public String toString() {
        return "Car{" +
                "speed=" + speed +
                ", acceleration=" + acceleration +
                ", creator=" + creator +
                ", state=" + state +
                '}';
    }
}
