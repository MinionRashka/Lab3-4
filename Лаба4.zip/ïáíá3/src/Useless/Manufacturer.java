package Useless;

public class Manufacturer {
    String name;
    String country;

    public Manufacturer(String name, String country){
        this.country = country;
        this.name = name;

        System.out.println("Наименование фирмы: " + name + "; Страна производитель: " + country);
    }

    public String getName(){return name;}
    public String getCountry(){return country;}
}
