import java.util.Objects;
import java.util.Scanner;

public class Cook extends Human implements Use{
    private Food eatable;
    private double skills;
    Scanner scanner = new Scanner(System.in);

    public Cook(String name, Gender gender, int HowStarve, double skills) {
        super(name, gender, HowStarve);
        try {
            if (skills>0 && skills <=1) this.skills = skills;
            else throw new ParameterException("Введите нормальное значение параметра skills");
        }catch(Exception e){
            while(skills <=0 || skills>1) {
                System.out.println("Введите нормальное значение параметра skills, принадлежащее от 0 не включительно до 1 включительно :");
                skills = scanner.nextDouble();
                this.skills = skills;
            }
        }
        System.out.println("Предыстория: " + getName() + " - повар c умением " + String.format("%.1f", skills * 100));
    }

    public Food getEatable(){return eatable;}
    public void setCook(Human cook, Thing food){
        this.eatable = eatable;
        System.out.println(cook.getName() + " прокрался и хочет приготовить" + food.getName());
    }

    @Override
    public boolean use(Human human, Thing thing) throws ThingException {
        if (thing instanceof Drink || thing instanceof Inedible) {
            try {
                throw new ThingException("Нельзя готовить несъедобное");
            } catch (Exception e) {
                System.out.println("Нельзя приготовить " + thing.getName());
            }
            return false;
        }
        else {
            System.out.println(human.getName() + " прокрался и приготовил " + thing.getName());
            return true;
        }
    }

    public boolean equals(Object otherObject)  {
        Cook other = (Cook) otherObject;
        return super.equals(other) && this.getEatable().equals(other.getEatable()) ;
    }
    public int hashCode()
    {
        return Objects.hash(this.getName(), this.getEatable());
    }
    public String toString() {
        return super.toString() + "[cook=" + this.getEatable() + "]";
    }

    public double getSkills() {
        return skills;
    }

    public void setMark(double skills) {
        this.skills += skills;
        System.out.println("Умение повара: " + String.format("%.1f", this.skills * 100));
    }
}
